//
//  ContentView.swift
//  GestureModifier
//
//  Created by BG4AMB0004 on 23/08/21.
//

import SwiftUI

struct ContentView: View {
    @GestureState private var isPressed = false
    @GestureState private var longPressTap = false
    @GestureState private var dragOffset = CGSize.zero
    @State private var position = CGSize.zero
    @GestureState private var dragState = DragState.inactive
    
    //    var body: some View {
    //        Image(systemName: "star.circle.fill")
    //            .font(.system(size: 200))
    //            .opacity(longPressTap ? 0.4 : 1)
    //            .scaleEffect(longPressTap ? 0.5 : 1)
    //            .foregroundColor(.green)
    //            .gesture(
    ////                TapGesture()
    ////                    .onEnded({
    ////                        print("Tapped!")
    ////                        self.isPressed.toggle()
    ////                    })
    //                LongPressGesture(minimumDuration: 1).updating($longPressTap, body: { (currentState, state, transaction) in
    //                     state = currentState
    //                }).onEnded({_ in
    //                    print("LongPress Tapped!")
    //                    self.isPressed.toggle()
    //                })
    //            )
    //    }
    //    var body: some View {
    //        Image(systemName: "star.circle.fill")
    //            .font(.system(size: 100))
    //            .offset(x: dragOffset.width, y: dragOffset.height)
    //            .animation(.easeInOut)
    //            .foregroundColor(.green)
    //            .gesture(
    //                DragGesture()
    //                    .updating($dragOffset, body: { (value, state, transaction) in
    //                        state = value.translation
    //                    })
    //            )
    //    }
    var body: some View {
        Image(systemName: "star.circle.fill")
            .font(.system(size: 100))
            .opacity(isPressed ? 0.5 : 1)
            .offset(x: position.width + dragOffset.width, y: position.width + dragOffset.height)
            .animation(.easeInOut)
            .foregroundColor(.green)
            .gesture(
                LongPressGesture(minimumDuration: 1.0)
                    .sequenced(before: DragGesture())
                    .updating($dragState, body: { value, state, transaction in
                        switch value{
                        case .first(true):
                            print("Tapping")
                            state = .pressing
                        case .second(true, let drag):
                            state = .dragging(translation: drag?.translation ?? .zero)
                        default:
                            break
                        }
                    })
                    .onEnded({ (value) in
                        guard case .second(true, let drag?) = value else {
                            return
                        }
                        print(drag)
                        self.position.height += drag.translation.height
                        self.position.width += drag.translation.width
                    })
            )
    }
}

enum DragState {
    case inactive
    case pressing
    case dragging(translation: CGSize)
    var translation: CGSize {
        switch self {
        case .inactive, .pressing:
            return .zero
        case .dragging(let translation):
            return translation
        }
    }
    var isPressing: Bool {
        switch self {
        case .pressing, .dragging:
            return true
        case .inactive:
            return false
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
